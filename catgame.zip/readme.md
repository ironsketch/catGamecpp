g++ -std=c++11 main.cc extra.cc cat.cc level.cc -framework SDL2 -framework SDL2_image -o catGame
